import React from 'react'
import './loader.css'

export default function Loader() {
  return (
     <>

         <div className="loader-main_div">
             <div className='loader-center_div'>
                
             </div>
         </div>

     </>
  )

}